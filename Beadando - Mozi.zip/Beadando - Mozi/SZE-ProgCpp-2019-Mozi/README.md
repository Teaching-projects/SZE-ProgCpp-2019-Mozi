# SZE-ProgCpp-2019-Mozi

> Projektünknek egy mozi rendszert tervezünk. Az adatok adatbázisban lesznek tárolva (felhasználónév, jelszó, kapacitás, terem). Első sorban konzolosan terveztük a megoldást. Funkciók között szerepel a login, egy moziban lévő termek kezelése, feltételek teljesülése (van elég pénz, férőhely, korhatár), jegyfoglalás.
