#include "Nyelv.cpp"
#include "Tipus.cpp"

class Film
{
	private:
		char cim[25];
		char rendezo[25];
		Nyelv ny; //=Magyar
		Tipus t;

		

};