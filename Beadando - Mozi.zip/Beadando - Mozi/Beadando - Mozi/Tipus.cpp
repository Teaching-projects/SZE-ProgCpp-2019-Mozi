enum Tipus 
{
	Akcio,
	Vigjatek,
	Thriller,
	Horror,
	Misztikus,
	Romantikus
};
