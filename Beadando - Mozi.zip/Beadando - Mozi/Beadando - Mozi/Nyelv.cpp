 enum  Nyelv 
{
	Magyar,
	Angol,
	Nemet,
	Francia,
	Japan
};
