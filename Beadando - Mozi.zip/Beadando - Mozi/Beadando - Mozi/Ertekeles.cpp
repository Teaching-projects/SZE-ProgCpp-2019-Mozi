#include <iostream>
#include "Ertekeles.hpp"
#include <string>



	void csillagkiir(int csillagdb)
	{

	}
